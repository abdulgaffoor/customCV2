import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
import NotFound from "pages/NotFound";
import LandingPage from './pages/landing-page';
import MatchReportDashboard from './pages/match-report-dashboard';
import ResumeAnalysisInput from './pages/resume-analysis-input';
import SideBySideComparison from './pages/side-by-side-comparison';
import OptimizedResumePreview from './pages/optimized-resume-preview';

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Define your route here */}
        <Route path="/" element={<LandingPage />} />
        <Route path="/landing-page" element={<LandingPage />} />
        <Route path="/match-report-dashboard" element={<MatchReportDashboard />} />
        <Route path="/resume-analysis-input" element={<ResumeAnalysisInput />} />
        <Route path="/side-by-side-comparison" element={<SideBySideComparison />} />
        <Route path="/optimized-resume-preview" element={<OptimizedResumePreview />} />
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;
