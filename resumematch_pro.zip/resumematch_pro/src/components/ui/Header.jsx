import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Button from './Button';
import Icon from '../AppIcon';

const Header = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);

  const handleNewAnalysis = async () => {
    setIsLoading(true);
    try {
      navigate('/resume-analysis-input');
    } finally {
      setTimeout(() => setIsLoading(false), 300);
    }
  };

  const handleLogoClick = () => {
    navigate('/landing-page');
  };

  const getProgressStep = () => {
    const path = location?.pathname;
    switch (path) {
      case '/landing-page':
        return { step: 0, label: 'Welcome' };
      case '/resume-analysis-input':
        return { step: 1, label: 'Upload Resume' };
      case '/match-report-dashboard':
        return { step: 2, label: 'Analysis Results' };
      case '/side-by-side-comparison':
        return { step: 3, label: 'Detailed Comparison' };
      case '/optimized-resume-preview':
        return { step: 4, label: 'Optimized Resume' };
      default:
        return { step: 0, label: 'Welcome' };
    }
  };

  const progress = getProgressStep();
  const showProgress = location?.pathname !== '/landing-page';

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background border-b border-border">
      <div className="flex items-center justify-between h-16 px-6">
        {/* Logo Section */}
        <div 
          className="flex items-center cursor-pointer transition-smooth hover:opacity-80"
          onClick={handleLogoClick}
        >
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Icon name="FileText" size={20} color="white" />
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-semibold text-primary">ResumeMatch</span>
              <span className="text-xs text-text-secondary font-medium">Pro</span>
            </div>
          </div>
        </div>

        {/* Progress Indicator */}
        {showProgress && (
          <div className="hidden md:flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 rounded-full bg-primary"></div>
              <span className="text-sm font-medium text-text-secondary">
                Step {progress?.step} of 4
              </span>
            </div>
            <div className="text-sm text-text-primary font-medium">
              {progress?.label}
            </div>
          </div>
        )}

        {/* Action Section */}
        <div className="flex items-center space-x-4">
          {location?.pathname !== '/resume-analysis-input' && (
            <Button
              variant="outline"
              size="sm"
              onClick={handleNewAnalysis}
              loading={isLoading}
              iconName="Plus"
              iconPosition="left"
              className="hidden sm:flex"
            >
              New Analysis
            </Button>
          )}
          
          {/* Mobile New Analysis Button */}
          {location?.pathname !== '/resume-analysis-input' && (
            <Button
              variant="outline"
              size="icon"
              onClick={handleNewAnalysis}
              loading={isLoading}
              className="sm:hidden"
            >
              <Icon name="Plus" size={16} />
            </Button>
          )}

          {/* Mobile Progress */}
          {showProgress && (
            <div className="md:hidden flex items-center space-x-2">
              <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
              <span className="text-xs font-medium text-text-secondary">
                {progress?.step}/4
              </span>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;