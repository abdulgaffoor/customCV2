import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

const SkillsAnalysisTab = () => {
  const [showMissingOnly, setShowMissingOnly] = useState(false);

  const skillsData = [
    { skill: 'React', matched: true, importance: 'high' },
    { skill: 'JavaScript', matched: true, importance: 'high' },
    { skill: 'Node.js', matched: true, importance: 'medium' },
    { skill: 'TypeScript', matched: false, importance: 'high' },
    { skill: 'GraphQL', matched: false, importance: 'medium' },
    { skill: 'Docker', matched: true, importance: 'medium' },
    { skill: 'AWS', matched: false, importance: 'high' },
    { skill: 'MongoDB', matched: true, importance: 'low' },
    { skill: 'Redux', matched: true, importance: 'medium' },
    { skill: 'Jest', matched: false, importance: 'medium' },
    { skill: 'Git', matched: true, importance: 'high' },
    { skill: 'Kubernetes', matched: false, importance: 'low' }
  ];

  const filteredSkills = showMissingOnly 
    ? skillsData?.filter(skill => !skill?.matched)
    : skillsData;

  const matchedCount = skillsData?.filter(skill => skill?.matched)?.length;
  const totalCount = skillsData?.length;

  const getImportanceColor = (importance) => {
    switch (importance) {
      case 'high': return 'bg-error text-white';
      case 'medium': return 'bg-warning text-white';
      case 'low': return 'bg-muted text-text-secondary';
      default: return 'bg-muted text-text-secondary';
    }
  };

  return (
    <div className="space-y-6">
      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-success/10 rounded-lg flex items-center justify-center">
              <Icon name="CheckCircle" size={20} color="var(--color-success)" />
            </div>
            <div>
              <div className="text-2xl font-bold text-success">{matchedCount}</div>
              <div className="text-sm text-text-secondary">Matched Skills</div>
            </div>
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-error/10 rounded-lg flex items-center justify-center">
              <Icon name="XCircle" size={20} color="var(--color-error)" />
            </div>
            <div>
              <div className="text-2xl font-bold text-error">{totalCount - matchedCount}</div>
              <div className="text-sm text-text-secondary">Missing Skills</div>
            </div>
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
              <Icon name="Target" size={20} color="var(--color-primary)" />
            </div>
            <div>
              <div className="text-2xl font-bold text-primary">
                {Math.round((matchedCount / totalCount) * 100)}%
              </div>
              <div className="text-sm text-text-secondary">Skills Match</div>
            </div>
          </div>
        </div>
      </div>
      {/* Filter Toggle */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-text-primary">
          Skills Analysis
        </h3>
        <div className="flex items-center space-x-3">
          <span className="text-sm text-text-secondary">Show missing only</span>
          <button
            onClick={() => setShowMissingOnly(!showMissingOnly)}
            className={`
              relative inline-flex h-6 w-11 items-center rounded-full transition-colors
              ${showMissingOnly ? 'bg-primary' : 'bg-muted'}
            `}
          >
            <span
              className={`
                inline-block h-4 w-4 transform rounded-full bg-white transition-transform
                ${showMissingOnly ? 'translate-x-6' : 'translate-x-1'}
              `}
            />
          </button>
        </div>
      </div>
      {/* Skills Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {filteredSkills?.map((skill, index) => (
          <div
            key={index}
            className={`
              flex items-center justify-between p-3 rounded-lg border transition-smooth
              ${skill?.matched 
                ? 'bg-success/5 border-success/20' :'bg-error/5 border-error/20'
              }
            `}
          >
            <div className="flex items-center space-x-3">
              <Icon
                name={skill?.matched ? "CheckCircle" : "XCircle"}
                size={16}
                color={skill?.matched ? "var(--color-success)" : "var(--color-error)"}
              />
              <span className="font-medium text-text-primary">
                {skill?.skill}
              </span>
            </div>
            <span className={`
              px-2 py-1 text-xs font-medium rounded-full
              ${getImportanceColor(skill?.importance)}
            `}>
              {skill?.importance}
            </span>
          </div>
        ))}
      </div>
      {filteredSkills?.length === 0 && (
        <div className="text-center py-8">
          <Icon name="Search" size={48} color="var(--color-muted-foreground)" className="mx-auto mb-4" />
          <p className="text-text-secondary">No skills found with current filter</p>
        </div>
      )}
    </div>
  );
};

export default SkillsAnalysisTab;